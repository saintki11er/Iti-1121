import java.util.Arrays;
import java.util.Scanner;
public class Q3_ArrayInsertionDemo{

    public static int[] insertIntoArray(int[] beforeArray, int indexToInsert, int valueToInsert) {
        int[] afterArray = new int[beforeArray.length + 1];
        for (int i = 0; i < indexToInsert; i++) {
            afterArray[i] = beforeArray[i];
        }
        afterArray[indexToInsert] = valueToInsert;
        for (int i = indexToInsert + 1; i < afterArray.length; i++) {
            afterArray[i] = beforeArray[i - 1];
        }
        return afterArray;
    }
    public static void main(String[] args) {
        int[] beforeArray = {1, 2, 3, 4, 5};
        System.out.println("Array before insertion: " + Arrays.toString(beforeArray));
        int[] afterArray = insertIntoArray(beforeArray, 2, 99);
        System.out.println("Array after insertion: " + Arrays.toString(afterArray));
    }
}