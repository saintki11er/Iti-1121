import java.util.Scanner;
class VotingRight{
     public static void main(String[] args){
        Scanner scanAge= new Scanner(System.in);
        System.out.print("how old are you: ");
        int myAge =scanAge.nextInt();
        scanAge.close();
        if(myAge < 18){
            System.out.println("Not old enough, wait until you are "+(18-myAge)+" y.o");
        }
        else{
            System.out.println("You are old enough");
        }
     }
}

	

