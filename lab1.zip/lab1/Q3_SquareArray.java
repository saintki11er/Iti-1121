public class Q3_SquareArray{

	public static int[] createArray(int size) {
		int[] array = new int[size];
		for (int i = 0; i<size; i++){
		    array[i] = i*i;
		}
		return array;
	}

	public static void main(String[] args){
		int[] resultats = createArray(13);
		for (int resultat : resultats){
		    System.out.println(resultat);
		}
	}
}