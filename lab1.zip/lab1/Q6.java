import java.util.Arrays;
import java.util.Scanner;
public class Q6{
	public static void main(String[] args) {
        // Prompt user to enter 10 numbers
        Scanner sc = new Scanner(System.in);
        double[] grades = new double[10];
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter a grade for student " + (i + 1) + ": ");
            grades[i] = sc.nextDouble();
        }
        sc.close();
        
    }

    public static double calculateAverage(double[] grades) {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        return sum / grades.length;
    }

    public static double calculateMedian(double[] grades) {
        Arrays.sort(grades);
        int middle = grades.length / 2;
        if (grades.length % 2 == 0) {
            return (grades[middle - 1] + grades[middle]) / 2;
        } else {
            return grades[middle];
        }
    }
	public static int calculateNumberFailed(double[] grades) {
        int failed = 0;
        for (double grade : grades) {
            if (grade < 50) {
                failed++;
            }
        }
        return failed;
    }
    public static int calculateNumberPassed(double[] grades) {
        int passed = 0;
        for (double grade : grades) {
            if (grade >= 50) {
                passed++;
            }
        }
        return passed;
    }
}